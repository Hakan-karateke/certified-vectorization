# Şekilden Denkleme 2.5

CAD ürün sonuçları: cad_product_validation/index.html
Araştırma ve boş pilot: pilot_workspace/index.html
Kullanım: documentation/pilot-workspace.md

FreeCAD başsız ürün deneyi: 27/27 geçti. AutoCAD/SolidWorks ve gerçek insan pilotu çalıştırılmadı. Kaynak kopyası source-2.5.zip içindedir; programlar/kurulu Python ortamı dahil değildir. Tam testleri yeniden üretmek için kaynak deposu ve test bağımlılıkları gerekir.
