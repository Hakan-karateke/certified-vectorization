"""Gerçek Tk olay döngüsünde üç ürünlü pilot kayıt ve araştırma ekranı."""

import json
import time
import tkinter as tk
from pathlib import Path

import pytest

from sekilden_denkleme.gui import AnalysisWindow
from sekilden_denkleme.pilot import REQUIRED, load_study, summarize
from sekilden_denkleme.project import load_project

ROOT = Path(__file__).parents[1]


def test_pilot_desktop_records_three_products_saves_reopens_and_reports(tmp_path, monkeypatch):
    """Deneme verisi insan sonucu olmaz; ana model ve kaydedilmemiş veriler korunur."""
    try:
        root = tk.Tk()
    except tk.TclError as error:
        pytest.skip(str(error))
    root.withdraw()
    app = AnalysisWindow(root)
    errors = []
    monkeypatch.setattr(
        "sekilden_denkleme.pilot_gui.messagebox.showerror", lambda *a, **k: errors.append(a)
    )
    monkeypatch.setattr("sekilden_denkleme.pilot_gui.messagebox.askyesno", lambda *a, **k: True)
    app.set_result(load_project(ROOT / "examples/cad_validation/ring/model.json"))
    original = app.result
    app.open_pilot()
    pilot = app.pilot_window

    def finish():
        deadline = time.monotonic() + 120
        ticks = [0]

        def tick():
            ticks[0] += 1
            if pilot.future is None or time.monotonic() > deadline:
                root.quit()
            else:
                root.after(10, tick)

        root.after(10, tick)
        root.mainloop()
        assert pilot.future is None and not errors, errors
        return ticks[0]

    try:
        pilot.start_timer()
        root.after(60, root.quit)
        root.mainloop()
        assert pilot.timer.elapsed() > 0
        pilot.timing.set("Elle ölçüm")
        assert pilot.timer.started is None
        pilot.fields["seconds"].set("1.5")
        root.after(300, root.quit)
        root.mainloop()
        assert pilot.fields["seconds"].get() == "1.5"
        for product in ("FreeCAD", "AutoCAD", "SolidWorks"):
            for key, value in {
                "participant": "TK-DEMO",
                "product": product,
                "product_version": "ui-test-only",
                "experience": "automated test",
                "baseline_method": "fixture",
                "case_id": "test-ring",
                "seconds": "1.5",
            }.items():
                pilot.fields[key].set(value)
            pilot.timing.set("Elle ölçüm")
            pilot.task_status.set("Tamamlandı")
            # Kalite kutularını işaretlemeden başarı kaydı eklenemez.
            pilot.record()
            assert errors and not any(t.product == product for t in pilot.study.trials)
            errors.clear()
            for key in REQUIRED["import"]:
                pilot.check_vars[key].set("Evet")
            pilot.record()
            root.update()
        assert len(pilot.study.trials) == 3
        assert summarize(pilot.study)["human_participants"] == 0
        assert app.result is original
        app.close()
        assert not app.closed and pilot.dirty
        saved = tmp_path / "pilot.json"
        monkeypatch.setattr(
            "sekilden_denkleme.pilot_gui.filedialog.asksaveasfilename", lambda **k: str(saved)
        )
        pilot.save()
        assert finish() > 0 and saved.exists() and not pilot.dirty
        assert len(load_study(saved).trials) == 3
        pilot.tree.selection_set(pilot.study.trials[0].id)
        root.update()
        assert pilot.editing_id == pilot.study.trials[0].id
        pilot.notes.insert("end", "field change")
        root.update()
        assert pilot.form_dirty
        pilot.record()
        root.update()
        assert len(pilot.study.trials) == 3
        pilot.save()
        finish()
        monkeypatch.setattr(
            "sekilden_denkleme.pilot_gui.filedialog.askopenfilename", lambda **k: str(saved)
        )
        pilot.open()
        finish()
        monkeypatch.setattr(
            "sekilden_denkleme.pilot_gui.filedialog.askdirectory",
            lambda **k: str(tmp_path / "report"),
        )
        pilot.export()
        finish()
        assert (tmp_path / "report/pilot.html").exists()
        pilot.report_current()
        finish()
        assert (tmp_path / "report/model-comparison.html").exists()
        assert app.result is original
    finally:
        pilot.close(force=True)
        app.close()


def test_pilot_desktop_freecad_real_background_product_check(tmp_path, monkeypatch):
    """Gerçek FreeCAD süreci ve Tk olay döngüsü birlikte çalışır; insan kaydı oluşmaz."""
    commands = list((ROOT / ".tmp/freecad").glob("*/bin/freecadcmd.exe"))
    if not commands:
        pytest.skip("Ayrı FreeCADCmd kurulu değil.")
    try:
        root = tk.Tk()
    except tk.TclError as error:
        pytest.skip(str(error))
    root.withdraw()
    app = AnalysisWindow(root)
    app.open_pilot()
    pilot = app.pilot_window
    errors = []
    monkeypatch.setattr(
        "sekilden_denkleme.pilot_gui.messagebox.showerror", lambda *a, **k: errors.append(a)
    )
    try:
        pilot.freecad_path.set(str(commands[0]))
        pilot.cad_path.set(str(ROOT / "examples/cad_validation/ring/reconstruction.step"))
        monkeypatch.setattr(
            "sekilden_denkleme.pilot_gui.filedialog.askdirectory", lambda **k: str(tmp_path)
        )
        pilot.run_compatibility()
        ticks = [0]
        deadline = time.monotonic() + 120

        def tick():
            ticks[0] += 1
            if pilot.future is None or time.monotonic() > deadline:
                root.quit()
            else:
                root.after(10, tick)

        root.after(10, tick)
        root.mainloop()
        assert not errors and pilot.future is None and ticks[0] > 1
        report = next(tmp_path.glob("freecad-*/compatibility.json"))
        assert json.loads(report.read_text())["evaluation"]["status"] == "passed"
        assert "passed" in pilot.status.get() and not pilot.study.trials
    finally:
        pilot.close(force=True)
        app.close()
