"""27 kayıtlı CAD dosyasını gerçek FreeCADCmd içe alıcısında sınar; insan verisi üretmez."""

import argparse
import hashlib
import html
import json
import platform
import sys
from pathlib import Path

from sekilden_denkleme.cad import export_cad
from sekilden_denkleme.cad_compatibility import run_freecad_check
from sekilden_denkleme.cad_geometry import CadOptions
from sekilden_denkleme.pilot import _table, atomic_text, html_page, utc_now
from sekilden_denkleme.project import load_project, save_project
from sekilden_denkleme.stress import source_digest


def main() -> None:
    """Ürün geçiş/başarısızlıklarını ham günlükler ve FCStd belgeleriyle raporlar."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--freecad", required=True, type=Path)
    parser.add_argument("--output", type=Path, default=Path("examples/cad_product_validation"))
    parser.add_argument(
        "--reexport",
        action="store_true",
        help="Aynı katsayıları mevcut yazıcıyla yeniden aktar; eski örnekleri koru",
    )
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    source = root / "examples/cad_validation"
    data = json.loads((source / "results.json").read_text(encoding="utf8"))
    records = []
    models = {}
    for row in data["records"]:
        path = source / row["file"].replace("\\", "/")
        directory = args.output / row["case"] / row["format"]
        record = {"case": row["case"], "format": row["format"], "cad_sha256": row["cad_sha256"]}
        try:
            if args.reexport:
                metadata = json.loads(
                    path.with_name(path.name + ".cad.json").read_text(encoding="utf8")
                )
                if row["case"] not in models:
                    models[row["case"]] = load_project(path.parent / "model.json")
                    save_project(models[row["case"]], args.output / row["case"] / "model.json")
                target = directory / path.name
                export_cad(
                    models[row["case"]],
                    target,
                    row["format"],
                    CadOptions(**metadata["cad_options"]),
                )
                path = target
                record["cad_sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
                record["source_cad_sha256_2_4"] = row["cad_sha256"]
            report = run_freecad_check(args.freecad, path, directory)
            result = json.loads(report.read_text(encoding="utf8"))
            record.update(
                status=result["evaluation"]["status"],
                report=report.relative_to(args.output.resolve()).as_posix(),
                evaluation=result["evaluation"],
                measured=result["measured"],
            )
        except Exception as error:
            record.update(status="error", reason=str(error))
        records.append(record)
        print(row["case"], row["format"], record["status"], flush=True)
        summary = {
            "schema_version": "1.0",
            "recorded_at": utc_now(),
            "python": platform.python_version(),
            "platform": platform.platform(),
            "application_source_sha256": source_digest(root / "src"),
            "reexported_without_refit": args.reexport,
            "executable": str(args.freecad.resolve()),
            "executable_sha256": hashlib.sha256(args.freecad.read_bytes()).hexdigest(),
            "records": records,
            "other_products": {
                "AutoCAD": {
                    "status": "not_run",
                    "reason": "Not installed in this environment; user plans installation on D:",
                },
                "SolidWorks": {
                    "status": "not_run",
                    "reason": "Not installed in this environment; user plans installation on D:",
                },
            },
            "human_participants": 0,
            "gui_tested": False,
            "scope": "Separate FreeCAD application with shared OCCT kernel family; no native CAD GUI or human usability claim.",
        }
        atomic_text(args.output / "results.json", json.dumps(summary, ensure_ascii=False, indent=2))
    if args.reexport:
        legacy = run_freecad_check(
            args.freecad, source / "components/reconstruction.iges", args.output / "legacy-2.4-iges"
        )
        legacy_result = json.loads(legacy.read_text(encoding="utf8"))
        summary["legacy_2_4_iges_regression"] = {
            "status": legacy_result["evaluation"]["status"],
            "reason": legacy_result["evaluation"].get("reason"),
            "report": legacy.relative_to(args.output.resolve()).as_posix(),
        }
        atomic_text(args.output / "results.json", json.dumps(summary, ensure_ascii=False, indent=2))
    body = "<p>27 dosya, gerçek FreeCADCmd içe alıcısı. OCCT çekirdeği ortaktır; arayüzde insan kullanımı sınanmadı. DXF yüz hazırlama adımı açıkça kaydedildi. Hacim iki ağ yoğunluğunda yönlü tetrahedron toplamıdır; varsayılan çekirdek hacmi de korunur. AutoCAD ve SolidWorks bu ortamda çalıştırılmadı. Gerçek katılımcı: 0.</p>"
    body += _table(
        ["Şekil", "Biçim", "Durum", "Ürün sürümü", "İçe alma s", "Ayrıntı"],
        [
            [
                r["case"],
                r["format"],
                r["status"],
                ".".join(r.get("measured", {}).get("version", [])[:3]),
                r.get("measured", {}).get("import_seconds"),
                r.get("report", r.get("reason", "")),
            ]
            for r in records
        ],
    )
    body += (
        "<h2>Deney raporları</h2><ul>"
        + "".join(
            f'<li><a href="{html.escape(r["report"].replace(".json", ".html"), quote=True)}">{html.escape(r["case"])} · {html.escape(r["format"].upper())}</a></li>'
            for r in records
            if "report" in r
        )
        + "</ul>"
    )
    body += (
        "<h2>Ham sonuçlar</h2><pre>"
        + html.escape(json.dumps(summary, ensure_ascii=False, indent=2))
        + "</pre>"
    )
    atomic_text(
        args.output / "index.html", html_page("Üç CAD hedefi: FreeCAD ürün doğrulaması", body)
    )
    print("Passed:", sum(r["status"] == "passed" for r in records), "/", len(records), flush=True)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf8")
    main()
