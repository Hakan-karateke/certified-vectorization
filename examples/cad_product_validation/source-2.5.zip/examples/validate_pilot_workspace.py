"""Boş insan pilotu ve aynı rasterin dört gerçek tolerans koşusunu raporlar."""

import json
import platform
import time
from pathlib import Path

from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure

from sekilden_denkleme import AnalysisConfig, analyze
from sekilden_denkleme.pilot import PilotStudy, atomic_text, export_study, html_page
from sekilden_denkleme.project import save_project
from sekilden_denkleme.research_report import export_comparison
from sekilden_denkleme.stress import source_digest


def main() -> None:
    """Süre ve ölçümleri gerçekten çalıştırır; eğitim başarısı veya insan verisi üretmez."""
    root = Path(__file__).resolve().parents[1]
    out = root / "examples/pilot_workspace"
    results, records = [], []
    fig = Figure(figsize=(12, 8), dpi=150, layout="constrained")
    FigureCanvasAgg(fig)
    for ax, epsilon in zip(fig.subplots(2, 2).flat, [1, 2, 3, 5], strict=True):
        config = AnalysisConfig(
            family="auto",
            tolerance=epsilon,
            padding=0,
            preference="balanced",
            certificate_mode="strict",
            embed_input=True,
        )
        started = time.perf_counter()
        result = analyze(root / "examples/validation/dataset/circle.png", config)
        seconds = time.perf_counter() - started
        save_project(result, out / f"circle_eps_{epsilon}.json")
        results.append(result)
        records.append(
            {
                "epsilon": epsilon,
                "seconds_analyze": seconds,
                "selected": result.selected_id,
                "pieces": len(result.selected.pieces),
                "score_bits": result.selected.complexity["score_bits"],
                "sampled_H": result.selected.metrics["sampled_hausdorff"],
                "numeric_upper": result.selected.metrics["hausdorff_upper_bound"],
                "certificate": result.selected.metrics.get("certification"),
                "project": f"circle_eps_{epsilon}.json",
            }
        )
        accepted = [c for c in result.candidates if c.accepted]
        ax.scatter(
            [c.complexity["score_bits"] for c in accepted],
            [c.metrics["hausdorff_upper_bound"] for c in accepted],
            s=28,
            label="Kabul edilmiş aday",
        )
        ax.scatter(
            [result.selected.complexity["score_bits"]],
            [result.selected.metrics["hausdorff_upper_bound"]],
            marker="*",
            s=180,
            c="#b6501b",
            label="Seçili",
        )
        ax.axhline(epsilon, c="#789080", ls="--", label="ε")
        ax.set(
            xscale="log",
            xlabel="Model maliyeti (bit, log ölçek)",
            ylabel="Sayısal U (çalışma birimi)",
            title=f"ε={epsilon} · {result.selected_id}",
        )
        ax.grid(alpha=0.2)
        ax.legend(fontsize=8)
        print(epsilon, result.selected_id, f"{seconds:.3f}s", flush=True)
    fig.suptitle(
        "Aynı raster sınırı · dört gerçek tolerans koşusu\nU sayısal üst tahmindir; bağımsız sertifika ayrıntıları rapordadır."
    )
    fig.savefig(out / "error-complexity.png")
    export_comparison(results, out / "research")
    export_study(PilotStudy(), out / "empty_pilot")
    atomic_text(
        out / "runs.json",
        json.dumps(
            {
                "application_source_sha256": source_digest(root / "src"),
                "python": platform.python_version(),
                "platform": platform.platform(),
                "reference": "same raster circle; no ideal object error measured",
                "records": records,
                "human_participants": 0,
            },
            ensure_ascii=False,
            indent=2,
        ),
    )
    body = '<p>Gerçek insan pilotu henüz yapılmadı. <a href="empty_pilot/pilot.html">Boş pilot raporu</a> · <a href="empty_pilot/pilot.json">Yeniden açılabilir boş çalışma</a></p><p><a href="research/model-comparison.html">Dört toleransın bütün adayları</a> · <a href="runs.json">Gerçek analiz süreleri ve sertifikalar</a></p><p>Grafikte kabul edilmiş adaylar gösterilir; retler de karşılaştırma raporunda yer alır. Aynı piksel sınırına uzaklık ölçülür; ideal çember veya insan öğrenme kazanımı değildir.</p><img src="error-complexity.png" alt="Dört toleransta hata ve model bit maliyeti">'
    atomic_text(out / "index.html", html_page("Araştırma ve pilot çalışma alanı örnekleri", body))


if __name__ == "__main__":
    main()
